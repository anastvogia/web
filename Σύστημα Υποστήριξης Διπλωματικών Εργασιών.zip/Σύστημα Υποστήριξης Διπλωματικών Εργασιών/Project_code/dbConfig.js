module.exports = {
    port: '3307',
    host: 'localhost',
    user: 'root',
    password: 'aggelos2004!',
    database: 'web'
  }
module.exports = {
    port: 'youport',
    host: 'yourhost',
    user: 'yourroot',
    password: 'yourpassword',
    database: 'yourdb'
  }